import csv
import os
import matplotlib.pyplot as plt


# ============================================================
#  CSV GENERATION
# ============================================================

def write_csv(filename, fieldnames, rows):
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print("Created {}".format(filename))


def generate_all_csvs():
    if not os.path.exists("turnout_demographics.csv"):
        write_csv(
            "turnout_demographics.csv",
            [
                "province",
                "voter_turnout_2019",
                "voter_turnout_2021",
                "age_between_18_34_population",
                "age_between_35_54_population",
                "age_for_55_plus_population",
                "total_population"
            ],
            [
                {"province": "Ontario", "voter_turnout_2019": "57.3", "voter_turnout_2021": "62.1",
                 "age_between_18_34_population": "4500000", "age_between_35_54_population": "5200000",
                 "age_for_55_plus_population": "3900000", "total_population": "13600000"}
            ]
        )

    if not os.path.exists("cpi_vote_change.csv"):
        write_csv(
            "cpi_vote_change.csv",
            [
                "province",
                "cpi_category",
                "cpi_change",
                "incumbent_vote_change"
            ],
            [
                {"province": "Ontario", "cpi_category": "Food", "cpi_change": "4.2", "incumbent_vote_change": "-1.8"},
                {"province": "Ontario", "cpi_category": "Transportation", "cpi_change": "6.1", "incumbent_vote_change": "-1.8"},
                {"province": "Ontario", "cpi_category": "Energy", "cpi_change": "9.5", "incumbent_vote_change": "-1.8"}
            ]
        )

    if not os.path.exists("jobs_votes.csv"):
        write_csv(
            "jobs_votes.csv",
            [
                "province",
                "party",
                "job_type",
                "avg_job_vacancy_rate",
                "vote_share_change"
            ],
            [
                {"province": "Ontario", "party": "Liberal", "job_type": "Healthcare",
                 "avg_job_vacancy_rate": "5.4", "vote_share_change": "-1.2"},
                {"province": "Quebec", "party": "Liberal", "job_type": "Healthcare",
                 "avg_job_vacancy_rate": "4.9", "vote_share_change": "-0.8"},
                {"province": "Alberta", "party": "Liberal", "job_type": "Healthcare",
                 "avg_job_vacancy_rate": "6.1", "vote_share_change": "-1.5"},
                {"province": "British Columbia", "party": "Liberal", "job_type": "Healthcare",
                 "avg_job_vacancy_rate": "5.0", "vote_share_change": "-0.6"},
                {"province": "Manitoba", "party": "Liberal", "job_type": "Healthcare",
                 "avg_job_vacancy_rate": "5.7", "vote_share_change": "-1.1"}
            ]
        )


# ============================================================
#  SHARED CSV LOADER
# ============================================================

def load_csv(filename):
    rows = []
    with open(filename, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for r in reader:
            rows.append(r)
    return rows


# ============================================================
#  QUESTION 1 — TURNOUT (BAR GRAPH)
# ============================================================

def plot_turnout_graph(province, turnout_2019, turnout_2021):
    plt.figure(figsize=(6,4))
    years = ["2019", "2021"]
    values = [turnout_2019, turnout_2021]

    bars = plt.bar(years, values, color=["skyblue", "steelblue"])
    plt.title("Voter Turnout in {}".format(province))
    plt.ylabel("Turnout (%)")

    for bar in bars:
        height = bar.get_height()
        plt.text(
            bar.get_x() + bar.get_width()/2,
            height + 0.5,
            "{:.1f}%".format(height),
            ha='center',
            va='bottom',
            fontsize=10
        )

    plt.ylim(0, max(values) + 10)
    plt.show()


def find_age_population(row, lower, upper):
    if lower == 18 and upper == 34:
        return int(row["age_between_18_34_population"])
    elif lower == 35 and upper == 54:
        return int(row["age_between_35_54_population"])
    elif lower >= 55:
        return int(row["age_for_55_plus_population"])
    else:
        raise ValueError("Age range not supported.")


def analyze_turnout(province, lower, upper):
    data = load_csv("turnout_demographics.csv")

    for row in data:
        if row["province"].lower() == province.lower():

            turnout_2019 = float(row["voter_turnout_2019"])
            turnout_2021 = float(row["voter_turnout_2021"])
            total_population = int(row["total_population"])

            age_population = find_age_population(row, lower, upper)

            turnout_change = turnout_2021 - turnout_2019
            age_share = age_population / total_population

            print("\n--- Voter Turnout Analysis ---")
            print("Province: {}".format(province))
            print("Age Range: {}-{}".format(lower, upper))
            print("Turnout 2019: {}".format(turnout_2019))
            print("Turnout 2021: {}".format(turnout_2021))
            print("Turnout Change: {}".format(turnout_change))
            print("Population Share: {:.2%}".format(age_share))

            plot_turnout_graph(province, turnout_2019, turnout_2021)
            return

    print("Province not found.")


# ============================================================
#  QUESTION 2 — CPI (SCATTER PLOT)
# ============================================================

def plot_cpi_scatter_all(data, category=None):
    plt.figure(figsize=(8,6))

    for row in data:
        if category is None or row["cpi_category"].lower() == category.lower():
            cpi_change = float(row["cpi_change"])
            vote_change = float(row["incumbent_vote_change"])
            province = row["province"]
            plt.scatter(cpi_change, vote_change, label=province)

    title_text = "CPI vs Vote Share Change ({})".format(category) if category else "CPI vs Vote Share Change (All Categories)"
    plt.title(title_text)
    plt.xlabel("CPI Change (%)")
    plt.ylabel("Vote Share Change (%)")
    plt.axhline(0, color="black", linewidth=0.8)
    plt.axvline(0, color="black", linewidth=0.8)
    plt.legend()
    plt.show()


def analyze_cpi_vote(category=None):
    data = load_csv("cpi_vote_change.csv")

    print("\n--- CPI & Vote Share Analysis ---")
    for row in data:
        if category is None or row["cpi_category"].lower() == category.lower():
            print("{} ({}): CPI {}%, Vote Change {}%".format(
                row['province'],
                row['cpi_category'],
                row['cpi_change'],
                row['incumbent_vote_change']
            ))

    plot_cpi_scatter_all(data, category)


# ============================================================
#  QUESTION 3 — MULTI‑PROVINCE HEALTHCARE DOUBLE‑BAR GRAPH
# ============================================================

def plot_jobs_double_bar(provinces, vacancy_rates, vote_changes, party, job_type):
    plt.figure(figsize=(10,6))

    x = range(len(provinces))
    width = 0.35

    plt.bar([p - width/2 for p in x], vacancy_rates, width,
            label="Vacancy Rate (%)", color="purple")
    plt.bar([p + width/2 for p in x], vote_changes, width,
            label="Vote Share Change (%)", color="teal")

    plt.xticks(x, provinces, rotation=45)
    plt.title("{} — {} Comparison Across Provinces".format(party, job_type))
    plt.ylabel("Percentage (%)")
    plt.legend()
    plt.tight_layout()
    plt.show()


def analyze_jobs_votes(province, party, job_type):
    data = load_csv("jobs_votes.csv")

    provinces = []
    vacancy_rates = []
    vote_changes = []

    for row in data:
        if row["party"].lower() == party.lower() and row["job_type"].lower() == job_type.lower():
            provinces.append(row["province"])
            vacancy_rates.append(float(row["avg_job_vacancy_rate"]))
            vote_changes.append(float(row["vote_share_change"]))

    if not provinces:
        print("No matching data found.")
        return

    print("\n--- Healthcare Vacancy & Vote Share Comparison Across Provinces ---")
    for p, v, vc in zip(provinces, vacancy_rates, vote_changes):
        print("{}: Vacancy {}%, Vote Change {}%".format(p, v, vc))

    plot_jobs_double_bar(provinces, vacancy_rates, vote_changes, party, job_type)


# ============================================================
#  MAIN MENU
# ============================================================

def main():
    generate_all_csvs()

    print("\n=== How Canada Votes — Analysis System ===")
    print("1. Voter Turnout & Demographics")
    print("2. CPI & Vote Share Change")
    print("3. Job Vacancy Rates & Party Vote Share")
    print("4. Exit")

    choice = input("Select an option: ").strip()

    if choice == "1":
        province = input("Enter province: ").strip()
        lower = int(input("Enter lower age: ").strip())
        upper = int(input("Enter upper age: ").strip())
        analyze_turnout(province, lower, upper)

    elif choice == "2":
        category = input("Enter CPI category (or leave blank for all): ").strip()
        if category == "":
            category = None
        analyze_cpi_vote(category)

    elif choice == "3":
        province = input("Enter province: ").strip()  # Ignored internally
        party = input("Enter party: ").strip()
        job_type = input("Enter job type: ").strip()
        analyze_jobs_votes(province, party, job_type)

    elif choice == "4":
        print("Exiting.")
        return

    else:
        print("Invalid selection.")


if __name__ == "__main__":
    main()
